<?php
require_once "vendor/autoload.php";

function dd($var){
    var_dump($var);die;
}